const anime = [
  {title:"Moonlit Legends", meta:"Action • Fantasy • 12 Episodes", tag:"Hindi Dub", letter:"M"},
  {title:"Neon Ronin", meta:"Sci-Fi • Action • 24 Episodes", tag:"Popular", letter:"N"},
  {title:"Skybound", meta:"Adventure • Fantasy • 13 Episodes", tag:"New", letter:"S"},
  {title:"Crimson Academy", meta:"School • Mystery • 12 Episodes", tag:"Hindi Dub", letter:"C"}
];
const movies = [
  {title:"The Last Star", meta:"Movie • 1h 52m", tag:"Movie", letter:"★"},
  {title:"Ocean of Dreams", meta:"Movie • 1h 48m", tag:"Adventure", letter:"O"},
  {title:"Spirit Blade", meta:"Movie • 2h 01m", tag:"Action", letter:"S"},
  {title:"Beyond Tomorrow", meta:"Movie • 1h 39m", tag:"Drama", letter:"B"}
];

function render(items,id){
  document.getElementById(id).innerHTML=items.map(x=>`
    <article class="card">
      <div class="poster" aria-label="${x.title} poster">${x.letter}</div>
      <div class="info">
        <div class="title">${x.title}</div>
        <div class="meta">${x.meta}</div>
        <span class="tag">${x.tag}</span>
      </div>
    </article>`).join("");
}
render(anime,"animeGrid"); render(movies,"movieGrid");

const toggle=document.getElementById("dataToggle");
toggle.addEventListener("click",()=>{
  const on=document.body.classList.toggle("low-data");
  toggle.textContent=on?"📶 Low Data: On":"📶 Low Data: Off";
  toggle.setAttribute("aria-pressed",on);
  localStorage.setItem("aniLowData",on?"1":"0");
});
if(localStorage.getItem("aniLowData")==="1") toggle.click();
